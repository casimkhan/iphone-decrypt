import sqlite3
import datetime
import re
import os
import pandas as pd


output_folder = 'sms_imessage_sorted'

print('Reading SQLite files')

con = sqlite3.connect("output/text_messages.sqlite")
df_message = pd.read_sql_query("SELECT * from message", con)
df_chat_message_join = pd.read_sql_query("SELECT * from chat_message_join", con)
df_chat = pd.read_sql_query("SELECT * from chat", con)
df_message_attachment_join = pd.read_sql_query("SELECT * from message_attachment_join", con)
df_attachment = pd.read_sql_query("SELECT * from attachment", con)
df_chat_handle_join = pd.read_sql_query("SELECT * from chat_handle_join", con)
df_handle = pd.read_sql_query("SELECT * from handle", con)
con.close()

con = sqlite3.connect("output/address_book.sqlite")
df_address_book = pd.read_sql_query("SELECT * FROM ABPersonFullTextSearch_content", con)
con.close()

# collated data dataframe
df_collated = pd.DataFrame(columns=['date_time', 'text', 'direction', 'chat_identifier', 'address_book_name', 'attachment_name', 'attachment_size'])

print('Formatting data in dataframes')
for index, row in df_message.iterrows():
    #print(row['text'])
    text = row['text']
    #print(datetime.datetime.fromtimestamp(row['date']/1000000000+978307200))
    date_time = str(datetime.datetime.fromtimestamp(row['date']/1000000000+978307200))
    if row['is_from_me'] == 1:
        #print('OUTGOING')
        direction = 'OUTGOING'
    else:
        #print('INCOMING')
        direction = 'INCOMING'
    row_chat_join = df_chat_message_join.loc[df_chat_message_join['message_id'] == row['ROWID']]
    if row_chat_join[['chat_id']].values:
        #print(row_chat_join[['chat_id']].values[0][0]) #chat_identifier
        row_chat = df_chat.loc[df_chat['ROWID'] == row_chat_join[['chat_id']].values[0][0]]
        #print(row_chat[['chat_identifier']].values[0][0])
        chat_identifier = row_chat[['chat_identifier']].values[0][0]

        #print(chat_identifier)
        row_name = df_address_book[df_address_book['c16Phone'].str.contains(re.escape(chat_identifier), na=False)]
        address_book_name = ''
        if len(row_name[['c0First']].values) > 0:
            if not row_name[['c0First']].values[0][0] == None:
                first_name = row_name[['c0First']].values[0][0]
        else:
            first_name = ' '

        if len(row_name[['c1Last']].values) > 0:
            if not row_name[['c1Last']].values[0][0] == None:
                last_name = row_name[['c1Last']].values[0][0]
            else:
                last_name = ' '
        else:
            last_name = ' '

        address_book_name = first_name + ' ' + last_name

        row_handle_join = df_chat_handle_join.loc[df_chat_handle_join['chat_id'] == row_chat_join[['chat_id']].values[0][0]]
        #print(row_handle_join[['handle_id']].values[0][0]) #id
        row_handle = df_handle.loc[df_handle['ROWID'] == row_handle_join[['handle_id']].values[0][0]]
        #print(row_handle[['id']].values[0][0]) # duplicate

    row_attachment_join = df_message_attachment_join.loc[df_message_attachment_join['message_id'] == row['ROWID']]

    if len(row_attachment_join[['message_id']].values) > 0:
        #print(row_attachment_join[['attachment_id']].values[0][0])
        row_attachment = df_attachment.loc[df_attachment['ROWID'] == row_attachment_join[['attachment_id']].values[0][0]]
        #print(row_attachment[['transfer_name']].values[0][0])
        attachment_name = row_attachment[['transfer_name']].values[0][0]
        #print(row_attachment[['total_bytes']].values[0][0])
        attachment_size = row_attachment[['total_bytes']].values[0][0]
    else:
        attachment_name = ''
        attachment_size = ''

    record = {'date_time':date_time, 'text':text, 'direction':direction, 'chat_identifier':chat_identifier, 'address_book_name':address_book_name, 'attachment_name':attachment_name, 'attachment_size':attachment_size}

    df_collated = df_collated.append(record, ignore_index=True)

    #print(record)
    #print(df_collated)


df_collated.sort_values(by=['date_time'], inplace=True)
#print(df_collated.to_string(index=False))
unique_chat_ids = df_collated.chat_identifier.unique()

print('Writing files to disk')

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

for id in unique_chat_ids:
    row_chat_id = df_collated.loc[df_collated['chat_identifier'] == id]
    csv_name = id
    if row_chat_id[['address_book_name']].values[0][0] != '   ':
        csv_name += ' - ' + row_chat_id[['address_book_name']].values[0][0]
    df_collated.loc[df_collated['chat_identifier'] == id].to_csv(os.path.join(output_folder,csv_name.strip() + '.csv'), index=False)
    #print(os.path.join(output_folder,csv_name.strip()))
    #print(df_collated.loc[df_collated['chat_identifier'] == id])
    #print('\n\n')




