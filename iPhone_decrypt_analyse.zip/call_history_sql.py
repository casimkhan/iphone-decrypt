import sqlite3
import datetime
import re
import os
import pandas as pd


output_folder = '.'

print('Reading SQLite files')

con = sqlite3.connect("output/call_history.sqlite")
df_call_record = pd.read_sql_query("SELECT * from ZCALLRECORD", con)
con.close()

con = sqlite3.connect("output/address_book.sqlite")
df_address_book = pd.read_sql_query("SELECT * FROM ABPersonFullTextSearch_content", con)
con.close()

# collated data dataframe
df_collated = pd.DataFrame(columns=['date_time', 'duration', 'direction', 'contact_number', 'address_book_name'])

print('Formatting data in dataframes')
for index, row in df_call_record.iterrows():
    #print(datetime.datetime.fromtimestamp(row['date']/1000000000+978307200))
    date_time = str(datetime.datetime.fromtimestamp(row['ZDATE']+978307200)).split('.')[0]
    if row['ZORIGINATED'] == 1:
        direction = 'OUTGOING'
    else:
        direction = 'INCOMING'

    duration = row['ZDURATION']

    if row['ZADDRESS'] != None:
        contact_number = row['ZADDRESS'].decode('utf-8')
        if contact_number.startswith('0'):
            contact_number = '+61' + contact_number[1:]
    else:
        contact_number = ' '

    row_name = df_address_book[df_address_book['c16Phone'].str.contains(re.escape(contact_number), na=False)]
    address_book_name = ''
    if len(row_name[['c0First']].values) > 0:
        if not row_name[['c0First']].values[0][0] == None:
            first_name = row_name[['c0First']].values[0][0]
    else:
        first_name = ' '
    if len(row_name[['c1Last']].values) > 0:
        if not row_name[['c1Last']].values[0][0] == None:
            last_name = row_name[['c1Last']].values[0][0]
        else:
            last_name = ' '
    else:
        last_name = ' '

    address_book_name = first_name + ' ' + last_name

    record = {'date_time':date_time, 'duration':duration, 'direction':direction, 'contact_number':contact_number, 'address_book_name':address_book_name}

    df_collated = df_collated.append(record, ignore_index=True)

    #print(record)
    print(df_collated)

'''
df_collated.sort_values(by=['date_time'], inplace=True)
#print(df_collated.to_string(index=False))
unique_chat_ids = df_collated.chat_identifier.unique()
'''
print('Writing files to disk')


df_collated.to_csv(os.path.join(output_folder, 'call_records.csv'), index=False)

