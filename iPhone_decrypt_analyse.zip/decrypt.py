from iphone_backup_decrypt import EncryptedBackup, RelativePath, RelativePathsLike

passphrase = "4n6"  # Or load passphrase more securely from stdin, or a file, etc.
backup_path = "00008020-0015192214B9002E-iPhone-Encrypted-Backup"

backup = EncryptedBackup(backup_directory=backup_path, passphrase=passphrase)

# Relative Paths

backup.extract_file(relative_path=RelativePath.CALL_HISTORY,
                    output_filename="./output/call_history.sqlite")

backup.extract_file(relative_path=RelativePath.ADDRESS_BOOK,
                    output_filename="./output/address_book.sqlite")

backup.extract_file(relative_path=RelativePath.TEXT_MESSAGES,
                    output_filename="./output/text_messages.sqlite")

backup.extract_file(relative_path=RelativePath.NOTES,
                    output_filename="./output/notes.sqlite")

backup.extract_file(relative_path=RelativePath.HEALTH,
                    output_filename="./output/health.sqlite")

backup.extract_file(relative_path=RelativePath.HEALTH_SECURE,
                    output_filename="./output/health_secure.sqlite")

backup.extract_file(relative_path=RelativePath.WHATSAPP_MESSAGES,
                    output_filename="./output/whatsapp_messages.sqlite")

backup.extract_file(relative_path=RelativePath.WHATSAPP_CONTACTS,
                    output_filename="./output/whatsapp_contacts.sqlite")

backup.extract_file(relative_path=RelativePath.INSTALLED_APPS,
                    output_filename="./output/kvs.sqlitedb")

# Relative Like

backup.extract_files(relative_paths_like=RelativePathsLike.CAMERA_ROLL,
                     output_folder="./output/camera_roll")

backup.extract_files(relative_paths_like=RelativePathsLike.SMS_ATTACHMENTS,
                     output_folder="./output/sms_attachments")

'''
backup.extract_files(relative_paths_like=RelativePathsLike.WHATSAPP_ATTACHED_IMAGES,
                     output_folder="./output/whatsapp_images")

backup.extract_files(relative_paths_like=RelativePathsLike.WHATSAPP_ATTACHED_VIDEOS,
                     output_folder="./output/whatsapp_videos")

backup.extract_files(relative_paths_like=RelativePathsLike.WHATSAPP_ATTACHED_DOCUMENTS,
                     output_folder="./output/whatsapp_documents")
'''

backup.extract_files(relative_paths_like=RelativePathsLike.WHATSAPP_ATTACHED_ALL,
                     output_folder="./output/whatsapp_all")


