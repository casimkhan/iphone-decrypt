import sqlite3
import datetime
import re
import os
import pandas as pd


output_folder = 'whatsapp_sorted'

print('Reading SQLite file')

con = sqlite3.connect("output/whatsapp_messages.sqlite")
df_message = pd.read_sql_query("SELECT * from ZWAMESSAGE", con)
df_media = pd.read_sql_query("SELECT * from ZWAMEDIAITEM", con)
df_contacts = pd.read_sql_query("SELECT * from ZWACHATSESSION", con)
con.close()

df_collated = pd.DataFrame(columns=['date_time', 'text', 'direction', 'chat_identifier', 'address_book_name', 'attachment_name', 'attachment_path', 'attachment_size'])

print('Formatting data in dataframes')
for index, row in df_message.iterrows():
    #print('Text:', row['ZTEXT'])
    text = row['ZTEXT']
    #print(datetime.datetime.fromtimestamp(row['ZMESSAGEDATE']+978307200))
    date_time = str(datetime.datetime.fromtimestamp(row['ZMESSAGEDATE']+978307200)).split('.')[0]
    address_book_name = ''
    attachment_name = ''
    attachment_path = ''
    attachment_size = 0
    if row['ZTOJID']:
        #print(row['ZTOJID'].split('@')[0])
        chat_identifier = row['ZTOJID'].split('@')[0]
        row_contacts = df_contacts.loc[df_contacts['ZCONTACTJID'] == row['ZTOJID']]
        if row_contacts['ZPARTNERNAME'].values:
            #print(row_contacts['ZPARTNERNAME'].values[0])
            address_book_name = row_contacts['ZPARTNERNAME'].values[0]
    if row['ZFROMJID']:
        #print(row['ZFROMJID'].split('@')[0])
        chat_identifier = row['ZFROMJID'].split('@')[0]
        row_contacts = df_contacts.loc[df_contacts['ZCONTACTJID'] == row['ZFROMJID']]
        if row_contacts['ZPARTNERNAME'].values:
            #print('From ID:', row_contacts['ZPARTNERNAME'].values[0])
            address_book_name = row_contacts['ZPARTNERNAME'].values[0]
    if row['ZISFROMME'] == 1:
        #print('OUTGOING')
        direction = 'OUTGOING'
    else:
        #print('INCOMING')
        direction = 'INCOMING'

    row_media = df_media.loc[df_media['ZMESSAGE'] == row['Z_PK']]
    if row_media[['ZAUTHORNAME']].values:
        #print(row_media[['ZAUTHORNAME']].values[0][0])
        attachment_name = row_media[['ZAUTHORNAME']].values[0][0]
    if row_media[['ZMEDIALOCALPATH']].values:
        #print(row_media[['ZMEDIALOCALPATH']].values[0][0].split('/')[-1])
        attachment_path = row_media[['ZMEDIALOCALPATH']].values[0][0].split('/')[-1]
    if row_media[['ZFILESIZE']].values:
        #print(row_media[['ZFILESIZE']].values[0][0])
        attachment_size = row_media[['ZFILESIZE']].values[0][0]


    record = {'date_time':date_time, 'text':text, 'direction':direction, 'chat_identifier':chat_identifier, 'address_book_name':address_book_name, 'attachment_name':attachment_name, 'attachment_size':attachment_size, 'attachment_path':attachment_path}

    df_collated = df_collated.append(record, ignore_index=True)

    #print(record)
    #print(df_collated)

df_collated.sort_values(by=['date_time'], inplace=True)
#print(df_collated.to_string(index=False))
unique_chat_ids = df_collated.chat_identifier.unique()


print('Writing files to disk')

if not os.path.exists(output_folder):
    os.makedirs(output_folder)

for id in unique_chat_ids:
    row_chat_id = df_collated.loc[df_collated['chat_identifier'] == id]
    csv_name = id
    if row_chat_id[['address_book_name']].values[0][0]:
        if '-' in id:
            csv_name += ' - GROUPCHAT - ' + row_chat_id[['address_book_name']].values[0][0]
        else:
            csv_name += ' - ' + row_chat_id[['address_book_name']].values[0][0]
    df_collated.loc[df_collated['chat_identifier'] == id].to_csv(os.path.join(output_folder,csv_name.strip() + '.csv'), index=False)
    #print(os.path.join(output_folder,csv_name.strip()))
    #print(df_collated.loc[df_collated['chat_identifier'] == id])
    #print('\n\n')
